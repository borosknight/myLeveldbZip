#include "coding.h"
#include <stdint.h>

namespace myLeveldb {
const char* DecodeEntry(
    const char* ptr, const char* limit,
    uint32_t* shared, uint32_t* nonShared, uint32_t* vSize
)
{
    const char* decodeHead = ptr;
    decodeHead = GetVarint32Ptr(decodeHead, decodeHead+5, shared);
    if (decodeHead == nullptr) { return decodeHead; }
    decodeHead = GetVarint32Ptr(decodeHead, decodeHead+5, nonShared);
    if (decodeHead == nullptr) { return decodeHead; }
    decodeHead = GetVarint32Ptr(decodeHead, decodeHead+5, vSize);
    if (decodeHead == nullptr) { return decodeHead; }
    if (decodeHead + *(nonShared) + *(vSize) > limit) { return nullptr; }
    return decodeHead;
}
}