
#ifndef ARENA_H // TOLN: 这个要写在#include前面
#define ARENA_H

#include <vector>
#include <atomic>
#include <cstddef> // size_t

// 用于将小型的堆上内存分配整合到各个相对大的block之中
// 减少内存分配释放带来的开销
// 同一block中分配内存只需要移动指针
class Arena {
public:
// ctor & dctor
    Arena():alloc_ptr_(nullptr), alloc_memory_remaining_(0), total_memory_(0) {};
    Arena(const Arena&) = delete;
    Arena& operator=(const Arena&) = delete;

// apis
    // 分配不一定对齐的内存，返回内存指针
    char* Allocate(size_t bytes);
    // 分配对齐一般到8字节的内存
    char* AllocateAligned(size_t bytes);
    // 一共用了多少内存。用来提供debug信息
    size_t GetMemoryUsed();

    // const
    static constexpr size_t kBlockSize = 4096;
    static_assert((kBlockSize & (kBlockSize-1)) == 0);
    // TODO: 或许应该判断是否align到sizeof(void*)以及8的更大者

private:
// private funcs
    // 不适合在当前block继续分配内存
    char* AllocateFallback(size_t bytes);

    // 简单的辅助函数
    void MovePtrWithinBlock(size_t bytes) {
        alloc_ptr_ += bytes;
        alloc_memory_remaining_ -= bytes;
    }

    // 是否就在AllocateNewBlock中移动alloc_ptr_？
    // 未必。
    char* AllocateNewBlock(size_t bytes);

// data members
    // 目前block剩余未分配内存的起始点
    char* alloc_ptr_;
    // 当前block剩余未分配内存量
    size_t alloc_memory_remaining_;
    // 本Arena分配了多少内存
    size_t total_memory_;

    std::vector<char*> blocks_;
};

#endif