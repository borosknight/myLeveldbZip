#include "memtable.h"
#include "coding.h"

namespace myLeveldb {

// TOLN: static=internal linkage=不会链接到到另一个编译单元=作用域仅本文件
static Slice GetLengthPrefixedSlice(const char* data)
{
    uint32_t length;
    const char* ptr = data;
    ptr = GetVarint32Ptr(ptr, ptr+5, &length);
    return Slice(ptr, length);
}

int MemTable::KeyComparator::operator()(const char* a, const char* b)
{
    Slice sliceA = GetLengthPrefixedSlice(a);
    Slice sliceB = GetLengthPrefixedSlice(b);
    return internalKeyComparator_.Compare(a, b);
}

void MemTable::Add(uint64_t sequenceNumber, ValueType flag,
    const Slice& key, const Slice& value)
{
    const size_t userKeySize = key.size();
    const size_t internalKeySize = userKeySize + 8;
    const size_t varint32KeySize = VarintLength(internalKeySize);
    const size_t valueSize = value.size();
    const size_t varint32ValueSize = VarintLength(valueSize);
    const size_t sizeNeeded = varint32KeySize+internalKeySize
        +varint32ValueSize+valueSize;
    char* mem = arena_.Allocate(sizeNeeded);
    char* dst = mem;
    dst = EncodeVarint32(dst, internalKeySize);
    memcpy(dst, key.data(), userKeySize);
    dst += userKeySize;
    dst = EncodeFixedUint64(dst, PackSeqFlag(sequenceNumber, flag));
    dst = EncodeVarint32(dst, valueSize);
    memcpy(dst, value.data(), valueSize);
    table_.Insert(mem);
}

bool MemTable::Get(const LookupKey& key, std::string* value, Status* status)
{
    Slice memTableKey = key.MemTableKey();
    Table::Iterator iter(&table_);
    iter.Seek(memTableKey.data());
    if (iter.Valid()) {
        const char* seekMemTableKeyPtr = iter.key();
        // TODO: 这里有些重复计算。comparator_会寻找internalKey的起始位置 sequence的起始位置
        // 这在if里面的逻辑又重复做了一遍。
        if (comparator_(memTableKey.data(), seekMemTableKeyPtr) == 0) {
            Slice seekInternalKey = GetLengthPrefixedSlice(seekMemTableKeyPtr);
            const char* seqPtr = seekInternalKey.data() + (seekInternalKey.size()-8);
            uint64_t seq = DecodeFixed64(seqPtr);
            ValueType flag = GetFlag(seq);
            switch (flag) {
            case TypeDelete:
                *status = status->NotFound(Slice());
                return false;
            case TypeValue:
                const char* valuePtr = seqPtr+8;
                // TOLN: 注释里的写法太罗嗦。
                // GetLengthPrefixedSlice也包含了长度信息。
                // string直接调用assign接口
                // uint32_t vSize;
                // const char* internalValuePtr = GetVarint32Ptr(valuePtr, valuePtr+5, &vSize);
                // memcpy(value->data(), internalValuePtr, vSize);
                Slice valueSlice = GetLengthPrefixedSlice(valuePtr);
                value->assign(valueSlice.data(), valueSlice.size());
                *status = status->OK();
                return true;
            }
        }        
    }
    return false;
}

}