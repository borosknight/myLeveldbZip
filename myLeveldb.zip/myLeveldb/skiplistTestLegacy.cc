#include "skiplist.h"
#include "bytewiseComparator.h"
#include <vector>

// g++ skipListTest.cc skipList.cc arena.cc -g -o skipListTest
using SLType = SkipList<const char*, BytewiseComparator>;
int main() {
    Arena arena;
    SLType sl(&arena, BytewiseComparator());
    std::vector<std::pair<const char*, int> > nodeHeightPairs = {
        {"78", 3},
        {"31", 2},
        {"35", 1},
        {"30", 2},
        {"15", 1},
        {"99", 1},
        {"94", 3},
        {"65", 4},
        {"51", 1}
    };
    for (auto pair : nodeHeightPairs) {
        sl.Insert(pair.first, pair.second);
    }
    sl.UglyVisualize();
}