#include "random.h"
#include <iostream>

void simpleTest(uint32_t seed) {
    Random rand = Random(seed);
    for (int i = 0; i < 10; i++) {
        std::cout << rand.Uniform(100) << " ";
    }
    std::cout << std::endl;
}

int main() {
    simpleTest(0xdeadbeefu);
    simpleTest(0xdeadbeefu);
    simpleTest(23u);
    simpleTest(23u);
    simpleTest(101u);
}