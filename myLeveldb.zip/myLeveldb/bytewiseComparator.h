#ifndef BYTEWISECMP_H
#define BYTEWISECMP_H
#include "string.h"
#include <algorithm>
struct BytewiseComparator {
    int compare(const char* charA, const char* charB) const {
        // TODO: DANGEROUS! 假如说charA不以\0结尾 麻烦大了
        size_t lenA = strlen(charA);
        size_t lenB = strlen(charB);
        int result = memcmp(charA, charB, std::min(lenA, lenB));
        if (result == 0) {
            if (lenA > lenB) {
                result = 1;
            } else if (lenA < lenB) {
                result = -1;
            }
        }
        return result;
    }
};

#endif