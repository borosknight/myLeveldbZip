#include <gtest/gtest.h>
#include "coding.h"  // myLeveldb 的 coding 头文件
#include <vector>
#include <iostream>

TEST(Coding, Varint32) {
    std::string s;
    s.reserve(32*32*5);
    for (uint32_t i = 0; i < (32 * 32); i++) {
        uint32_t v = (i / 32) << (i % 32);
        PutVarint32(&s, v);
    }

    const char* p = s.data();
    const char* limit = p + s.size();
    for (uint32_t i = 0; i < (32 * 32); i++) {
        uint32_t expected = (i / 32) << (i % 32);
        uint32_t actual;
        std::cout<< "Doing " << i << std::endl;
        const char* start = p;
        p = GetVarint32Ptr(p, limit, &actual);
        ASSERT_TRUE(p != nullptr);
        ASSERT_EQ(expected, actual);
        ASSERT_EQ(VarintLength(actual), p - start);
    }
    ASSERT_EQ(p, s.data() + s.size());
}

TEST(Coding, Fixed64) {
    std::string s;
    s.reserve(64*8*3);
    for (int power = 0; power <= 63; power++) {
      uint64_t v = static_cast<uint64_t>(1) << power;
      PutFixed64(&s, v - 1);
      PutFixed64(&s, v + 0);
      PutFixed64(&s, v + 1);
    }
  
    const char* p = s.data();
    for (int power = 0; power <= 63; power++) {
      uint64_t v = static_cast<uint64_t>(1) << power;
      uint64_t actual;
      actual = DecodeFixed64(p);
      ASSERT_EQ(v - 1, actual);
      p += sizeof(uint64_t);
  
      actual = DecodeFixed64(p);
      ASSERT_EQ(v + 0, actual);
      p += sizeof(uint64_t);
  
      actual = DecodeFixed64(p);
      ASSERT_EQ(v + 1, actual);
      p += sizeof(uint64_t);
    }
}