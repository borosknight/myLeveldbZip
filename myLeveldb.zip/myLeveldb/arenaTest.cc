#include "arena.h"

// g++ -g arenaTest.cc arena.cc -o arenaTest
int main() {
    Arena arena;
    // 预期allocate一个single block
    char* mem1 = arena.Allocate(2999);
    char* alloc1 = new (mem1) char[2000]; // allocate new block
    char* mem2 = arena.AllocateAligned(150);
    char* alloc2 = new (mem2) char[10];// allocate a new block and then within
    char* mem3 = arena.Allocate(4096-150-10);
    char* alloc3 = new(mem3) char[1000]; // allocate within
    char* mem4 = arena.AllocateAligned(101);
    char* alloc4 = new(mem4) char[78]; // allocate a new block
}