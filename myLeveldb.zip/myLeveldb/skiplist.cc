#include "skiplist.h"
#include "bytewiseComparator.h"
#include "skiplistTest.h"
#include <iostream>

// 本来应该是循环高度 然后循环同一个高度上的链表
// 这里将两个循环合二为一。
// TODO: 或许应该将抛硬币得到的height也作为参数？毕竟只需要在<=height之下的那些前继结点
template<typename Key, typename Comparator>
typename SkipList<Key, Comparator>::Node*
    SkipList<Key, Comparator>::FindGreaterOrEqual
    (const Key& key, SkipList<Key, Comparator>::Node** prevs) const
{
    int curHeight = GetMaxHeight()-1;
    Node* curNode = head_;
    while (true) {
        if (KeyIsAfterNode(key, curNode->Next(curHeight))) {
            // 继续在本层的遍历
            curNode = curNode->Next(curHeight);
        } else {
            // 发现了最后一个key大于的结点
            // !=nullptr是为了Contains接口 纯找相同节点而不管prevs
            if (prevs != nullptr) {
                prevs[curHeight] = curNode;
            }
            if (curHeight == 0) {
                return curNode->Next(curHeight);
            }
            curHeight--;
        }
    }
}

template<typename Key, typename Comparator>
void SkipList<Key, Comparator>::Insert
    (const Key& key, int designatedHeight)
{
    Node* prevs[kMaxHeight];
    FindGreaterOrEqual(key, prevs);
    int height = (designatedHeight!=-1)?designatedHeight:CoinHeight();
    if (height > GetMaxHeight()) {
        for (int h = GetMaxHeight(); h < height; h++) {
            prevs[h] = head_;
        }
        maxHeight_ = height;
    }
    Node* insNode = NewNode(key, height);
    // 将新建结点插入各层链表中
    for (int h = 0; h < height; h++) {
        insNode->SetNext(prevs[h]->Next(h), h);
        prevs[h]->SetNext(insNode, h);
    }
}

template<typename Key, typename Comparator>
int SkipList<Key, Comparator>::CoinHeight()
{
    static constexpr uint32_t k = 4;
    int height = 1;
    while (rnd_.OneIn(k) && height <= kMaxHeight) {
        height++;
    }
    return height;
}

template<typename Key, typename Comparator>
bool SkipList<Key, Comparator>::Contains(const Key& key) const
{
    Node* greaterOrEqualNode = FindGreaterOrEqual(key, nullptr);
    return greaterOrEqualNode != nullptr && Equal(key, greaterOrEqualNode->key);
}

template<typename Key, typename Comparator>
void SkipList<Key, Comparator>::UglyVisualize() const
{
    int curHeight = GetMaxHeight()-1;
    Node* curNode = head_->Next(curHeight);
    while (true) {
        if (curNode != nullptr) {
            std::cout << curNode->key << "->";
            curNode = curNode->Next(curHeight);
        } else {
            std::cout << std::endl;
            if (curHeight == 0) {
                return;
            }
            curHeight--;
            curNode = head_->Next(curHeight);
        }
    }
}

template class SkipList<const char*, BytewiseComparator>;
template class SkipList<uint64_t, TestComparator>;
// TODO: 部分实例化
// template
// typename SkipList<const char*, BytewiseComparator>::Node*
// SkipList<const char*, BytewiseComparator>::FindGreaterOrEqual
// (
//     const char*& key,
//     SkipList<const char*, BytewiseComparator>::Node** prevs
// );