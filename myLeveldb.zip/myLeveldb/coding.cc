#include "coding.h"

char* EncodeVarint32(char* buf, uint32_t v)
{
    uint8_t* ptr = reinterpret_cast<uint8_t*>(buf);
    static const uint8_t m = 1u<<7; // 1<<7=0b10000000;第八位是1
    if (v < (1<<7)) { // TOLN: 每次处理7位数，然后第八位作为标志位
        (*ptr++) = v; // TODO: 不太好的隐式截断。最好用static_cast
    } else if (v < (1u<<14)) {
        (*ptr++) = v|m;
        (*ptr++) = v>>7; // 这个++是需要的！要返回ptr并且指向encode以后的位置
    } else if (v < (1u<<21)) {
        (*ptr++) = v|m;
        (*ptr++) = (v>>7)|m;
        (*ptr++) = (v>>14);
    } else if (v < (1u<<28)) {
        (*ptr++) = v|m;
        (*ptr++) = (v>>7)|m;
        (*ptr++) = (v>>14)|m;
        (*ptr++) = v>>21;
    } else {
        (*ptr++) = v|m;
        (*ptr++) = (v>>7)|m;
        (*ptr++) = (v>>14)|m;
        (*ptr++) = v>>21|m;
        (*ptr++) = v>>28;
    }
    return reinterpret_cast<char*>(ptr);
}

void PutVarint32(std::string* dst, uint32_t v)
{
    char buf[5];
    char* ptr = EncodeVarint32(buf, v);
    dst->append(buf, ptr - buf);
}

// 雷点1: v==0时候Length也得是1
// 雷电2: 128的varint32 encode是00000001|10000000
//        所以是存在某一段encoding是10000000的情况的
//        所以要用v>=128而不是v>128
// 雷点3: >>=而不是>>
size_t VarintLength(uint32_t v)
{
    size_t length = 1;
    while (v >= 128) {
        v >>= 7;
        length++;
    }
    return length;
}

uint32_t DecodeVarint32(const char* buf)
{
    auto ptr = reinterpret_cast<const uint8_t*>(buf);
    uint32_t result = 0;
    constexpr static uint8_t flag = (1 << 7);
    constexpr static uint8_t mask = flag-1;
    for (int i = 0; i < 5; i++) {
        uint8_t varNum = *(ptr++);
        result |= (static_cast<uint32_t>((varNum & mask))<<(7*i));
        // TOLN: 运算符优先级
        if ((varNum & flag) == 0) { break; }
    }
    return result;
}

const char* GetVarint32PtrFallback(const char* p, const char* limit,
    uint32_t* value)
{
    const uint8_t* u8Ptr = reinterpret_cast<const uint8_t*>(p);
    uint32_t result = 0;
    // 当shift==28的时候 却依旧没有走到(byte & 128) == 0里面
    // 此时就说明这是一个错误的varint32编码：它的第五个字节的flag依旧是1
    // 此时返回nullptr
    for (int shift = 0; shift <= 28 && p < limit; shift += 7) {
        uint32_t byte = *u8Ptr;
        u8Ptr++;
        if ((byte & 128) == 0) {
            result |= (byte << shift);
            *value = result;
            return reinterpret_cast<const char*>(u8Ptr);
        } else {
            result |= (byte & 127) << shift;
        }
    }
    return nullptr;
}

const char* GetVarint32Ptr(const char* p, const char* limit,
    uint32_t* value)
{
    // TODO: FAST PATH
    return GetVarint32PtrFallback(p, limit, value);
}

char* EncodeFixedUint64(char* buf, uint64_t v)
{
    uint8_t* ptr = reinterpret_cast<uint8_t*>(buf);
    // TODO: 并不高效的写法，但是看起来不傻。
    for (int i = 0; i < 8; i++) {
        // TOLN: 用static_cast来进行截断
        (*ptr++) = static_cast<uint8_t>(v >> (i*8));
    }
    return reinterpret_cast<char*>(ptr);
}

uint64_t DecodeFixed64(const char* buf)
{
    uint64_t result = 0;
    const uint8_t* ptr = reinterpret_cast<const uint8_t*>(buf);
    for (int shift = 0; shift <= 56; shift += 8) {
        uint64_t u64Num = *ptr;
        ptr++;
        result |= (u64Num << shift);
    }
    return result;
}

void PutFixed64(std::string* dst, uint64_t v)
{
    char buf[8];
    char* ptr = EncodeFixedUint64(buf, v);
    dst->append(buf, 8);
}

static char* EncodeFixedUint32(char* buf, uint64_t v)
{
    uint8_t* ptr = reinterpret_cast<uint8_t*>(buf);
    // TODO: 并不高效的写法，但是看起来不傻。
    for (int shift = 0; shift <= 24; shift += 8) {
        // TOLN: 用static_cast来进行截断
        (*ptr++) = static_cast<uint8_t>(v >> shift);
    }
    return reinterpret_cast<char*>(ptr);
}

void PutFixed32(std::string* dst, uint32_t v)
{
    // TOLN: 为什么不直接dst.data()上进行操作？
    // 因为万一超过capacity了呢？要利用其自动的内存管理机制。
    char buf[4];
    char* ptr = EncodeFixedUint32(buf, v);
    dst->append(buf, 4);
}