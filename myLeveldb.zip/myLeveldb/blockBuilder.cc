#include "blockBuilder.h"
#include "coding.h"
#include <cassert>

namespace myLeveldb {
void BlockBuilder::Add(const Slice& key, const Slice& value)
{
    assert(!finished_);
    assert(
        buffer_.empty() ||
        options_->comparator->Compare(key, last_key_) >= 0
    );
    assert(counter_ < options_->restartInterval && counter_ >= 0);
    size_t shared = 0; // 因为要用做索引 还是用size_t而非uint32_t
    size_t minLen = (key.size() < last_key_.size())?key.size():last_key_.size();
    // 不需要用At因为小于minLen 相当于做了边界检查。
    // TODO: 官方的实现是如果counter >= options_->restartInterval
    // 则跳过这个while的步骤，然后counter归0。
    while (shared < minLen && key[shared] == last_key_[shared]) {
        shared++;
    }
    PutVarint32(&buffer_, static_cast<uint32_t>(shared));
    size_t notShared = key.size()-shared;
    PutVarint32(&buffer_, static_cast<uint32_t>(notShared));
    PutVarint32(&buffer_, static_cast<uint32_t>(value.size()));
    buffer_.append(key.data(), key.size());
    buffer_.append(value.data(), value.size());
    counter_++;
    if (counter_ >= options_->restartInterval) {
        restarts_.push_back(buffer_.size());
        counter_ = 0;
        last_key_.clear();
    } else {
        last_key_.resize(shared);
        last_key_.append(key.data()+shared, notShared);
        assert(Slice(last_key_) == key);
    }
}

Slice BlockBuilder::Finish()
{
    assert(!finished_);
    for (uint32_t restart:restarts_) {
        PutFixed32(&buffer_, restart);
    }
    PutFixed32(&buffer_, restarts_.size());
    finished_ = false;
    return Slice(buffer_);
}
}