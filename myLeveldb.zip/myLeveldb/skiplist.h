#ifndef SKIPLIST_H
#define SKIPLIST_H
#include "arena.h"
#include "random.h"
#include <cassert>

template<typename Key, typename Comparator>
class SkipList {
private:
    // 辅助类
    struct Node; // 使用struct表示其数据成员的开放性
public:
// ctor dctor
    SkipList(Arena* arena, Comparator cmp)
     : arena_(arena), maxHeight_(1), comparator_(cmp),
       head_(NewNode(0, kMaxHeight)), rnd_(Random(0xdeadbeef)) {
        for (int h = 0; h < kMaxHeight; h++) {
            head_->SetNext(nullptr, h);
        }
    }
    SkipList(const SkipList&) = delete;
    SkipList& operator=(const SkipList&) = delete;

// apis
    // 插入一个新的结点
    void Insert(const Key& key, int designatedHeight = -1);
    bool Contains(const Key& key) const;
    void UglyVisualize() const;

// const
    static constexpr int kMaxHeight = 12;

// iterator
    class Iterator {
    public:
        // Initialize an iterator over the specified list.
        // The returned iterator is not valid.
        explicit Iterator(const SkipList* list) : list_(list), node_(nullptr) {}

        // Returns true iff the iterator is positioned at a valid node.
        bool Valid() const { return node_ != nullptr; }

        // Returns the key at the current position.
        // REQUIRES: Valid()
        const Key& key() const {
            assert(Valid());
            return node_->key;
        }

        // Advances to the next position.
        // REQUIRES: Valid()
        void Next() {
            assert(Valid());
            node_ = node_->Next(0);
        }

        // Advance to the first entry with a key >= target
        void Seek(const Key& target) {
            node_ = list_->FindGreaterOrEqual(target, nullptr);
        }
    
    private:
        const SkipList* list_;
        Node* node_;
        // Intentionally copyable
    };

private:
// private func
    // 找到所有层中该key大于或等于的最大结点 存储在prevs中
    // 之后就可以利用prevs进行insert
    // TOLN: 弱智错误Node* FindGreaterOrEqual(const& Key key, Node** prevs);
    // &修饰在了const上
    Node* FindGreaterOrEqual(const Key& key, Node** prevs) const;
    // 用在FindGreaterOrEqual上 而FindGreaterOrEqual又会被用在contains里
    // contains的逻辑是看FindGreaterOrEqual的返回的Next结点是否和查询key相等
    // 那么如果key == next.key 此时应当返回false
    // 从而让FindGreaterOrEqual返回next
    bool KeyIsAfterNode(const Key& key, Node* node) const {
        return (node != nullptr) && (comparator_.compare(node->key, key) < 0);
    };
    bool Equal(const Key& key1, const Key& key2) const {
        return comparator_.compare(key1, key2) == 0;
    }
    int GetMaxHeight() const { return maxHeight_; }
    Node* NewNode(const Key& key, int height) {
        // TOLN: 为何下下行的自动补全无效，因为这一行忘记加;了
        size_t nodeSize = sizeof(Node) /*已经包含一个next node了*/ + sizeof(Node*) * (height-1);
        char* mem = arena_->AllocateAligned(nodeSize);
        return new (mem) Node(key);
    };
    int CoinHeight();

// data members
    // 并不是包含 而是关联关系
    // TOLN: 声明顺序=初始化顺序！
    Arena* arena_;
    Node* head_;
    Comparator comparator_;
    int maxHeight_;
    Random rnd_;
};

template<typename Key, typename Comparator>
struct SkipList<Key, Comparator>::Node {
public:
// ctor & dctor
    explicit Node(const Key& _key) : key(_key) {}

// apis
    // TOLN: 这里为何用int而不是size_t?
    // 或许bytes这种和内存直接联系的才用size_t?
    Node* Next(int n) {
        return next_[n];
    }
    Key key;

    void SetNext(Node* node, int n) {
        next_[n] = node;
    }

private:
// data members
    // TOLN: 1只是占位 由于是手动分配堆内存 实际上分配了height*sizeof(Node*)
    // 剩余的都可以通过next_[n]获取
    Node* next_[1];
};
#endif