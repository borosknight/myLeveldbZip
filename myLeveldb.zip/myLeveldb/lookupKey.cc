#include "lookupKey.h"
#include "coding.h"
#include <cassert>
#include <bitset>
#include <iostream>

// TOLN: .cc里也要注明namespace
// 不注明则无法识别 并且vscode也不会自动补全
// 比如lookupKey.h里的东西都放在myleveldb里
// 如果在lookupKey.cc里 不在myLeveldb里敲击LookUp
// 则无法自动补全为LookupKey
namespace myLeveldb {
uint64_t PackSeqFlag(uint64_t sequenceNumber, ValueType v)
{
    // TOLN: 1<<56超出范围
    assert(sequenceNumber < (1ULL<<56));
    return ((sequenceNumber << 8) | v);
}

uint64_t GetSeqNum(uint64_t packedSeqFlag)
{
    return (packedSeqFlag >> 8);
}

ValueType GetFlag(uint64_t packedSeqFlag)
{
    uint64_t value = (packedSeqFlag & 0xff);
    assert(value <= kTypeSearch);
    return static_cast<ValueType>(value);
}

LookupKey::LookupKey(const Slice& ukey, SeqNumType sequenceNumber)
{
    size_t usize = ukey.size();
    constexpr static int internalSizeNeeded = 5;
    constexpr static int sequenceNumNeeded = 8;
    size_t needed = usize+internalSizeNeeded+sequenceNumNeeded;
    // TOLN: 这么做就导致dst = start_失败
    // if (needed > sizeof(space_)) {
    //     start_ = new char[needed];
    // } else {
    //     start_ = space_;
    // }
    // const char* dst = start_;
    char* dst_ = nullptr;
    if (needed > sizeof(space_)) {
        dst_ = new char[needed];
    } else {
        dst_ = space_;
    }
    start_ = dst_;
    size_t internalKeyNeeded = usize+internalSizeNeeded;
    // key size不太可能超出uint32吧...
    dst_ = EncodeVarint32(dst_, static_cast<uint32_t>(usize+8));
    kstart_ = dst_;
    memcpy(dst_, ukey.data(), usize);
    dst_ += usize;
    dst_ = EncodeFixedUint64(dst_, PackSeqFlag(sequenceNumber, kTypeSearch));
    end_ = dst_;
}

void LookupKey::print()
{
    const char* ptr = start_;
    std::cout << DecodeVarint32(ptr) << "|";
    for (;ptr < kstart_;ptr++) {
        auto u8ptr = reinterpret_cast<const uint8_t*>(ptr);
        std::cout << std::bitset<8>(*u8ptr) << "|";
    }
    // TODO: use decoded length instead of end_ to test
    for (;ptr < end_-8; ptr++) {
        std::cout << (*ptr);
    }
    std::cout << "|";
    uint64_t packedSeqFlag = *(reinterpret_cast<const uint64_t*>(ptr));
    std::cout << GetSeqNum(packedSeqFlag) << "|";
    constexpr int low8Mask = (1<<8)-1;
    std::cout << (packedSeqFlag & low8Mask) << std::endl;
}

}