#ifndef LEVELDB_BLOCKBUILDER_H
#define LEVELDB_BLOCKBUILDER_H
#include "options.h"
#include "slice.h"
#include <vector>
#include <string>

namespace myLeveldb {
// 最重要的假设：是按照key依次递增的顺序加入的
class BlockBuilder {
public:
// ctor & dctor
    BlockBuilder(const Options* opt) : 
        options_(opt), counter_(0), finished_(false)
    {
        restarts_.push_back(0);
    }
    BlockBuilder(const BlockBuilder&) = delete;
    BlockBuilder& operator=(const BlockBuilder&) = delete;
// api
    void Add(const Slice& key, const Slice& value);
    // return a reference? 那么得确保BlockBuilder作为被包含的关系来用了...
    // 有没有可能不return reference呢？
    // 如果返回copy 那么性能就不太好
    // 可能可以通过类似std::move这样的方法转交buffer_
    Slice Finish();

private:
// data members
    const Options* options_;
    int counter_; // restart interval之内的计数
    bool finished_; // 如果为true 说明已经把restart points都加入到buffer_了
    // 此时不能再调用Add 或者Finish
    std::string buffer_; // 将一切写入buffer_中
    // 为什么使用std::string
    // 因为1.你不知道要写入多少东西 那就不能用静态数组
    // 2.最终的buffer必须得是连续的 那么也不能Add一次就new一次 或者是Arena那样的每个
    // block之间不连续。
    // 那么自动又连续的 还算不是特别浪费的std::string式内存管理就适合这个场景了。
    std::vector<uint32_t> restarts_; // 记录重启点
    std::string last_key_; // 为了计算共享前缀
};
}
#endif