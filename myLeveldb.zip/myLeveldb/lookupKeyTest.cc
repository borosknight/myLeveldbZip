#include "lookupKey.h"
// g++ -g coding.cc lookupKey.cc lookupKeyTest.cc -o lookupKeyTest
int main()
{
    const char* ukey = "Illusory";
    uint64_t seq = 20250205ULL;
    myLeveldb::LookupKey lk(ukey, seq);
    lk.print();
}