#ifndef LEVELDBSLICE_H
#define LEVELDBSLICE_H
#include <string>
#include <string.h>

// approximate to const char* + size
// 相比起单独用const char*好处就是函数传参不用额外传一个size_t size参数
// 所以：需要知道const char*到底size多大的时候 就用slice;
// 不需要知道，那直接用const char*
struct Slice {
// ctor & dctor
    Slice() : data_(""), size_(0) {}
    Slice(std::string str) : data_(str.data()), size_(str.size()) {}
    // TODO & TOLN: DANGEROUS!只能用在chr的确是个字符串 而不是某个key的buffer
    // strlen依赖于末尾存在\0 才能计数；否则就会一路走 直到碰到哪里有\0才停下
    Slice(const char* chr) : data_(chr), size_(strlen(chr)) {}
    Slice(const char* chr, size_t len) : data_(chr), size_(len) {}

    Slice(const Slice&) = default;
    Slice& operator=(const Slice&) = default;
    char operator[](size_t index) const
    {
        return data_[index];
    }
    // TOLN: 和std::string一样 At会检查边界
    char At(size_t index) const
    {
        assert(index < size_);
        return operator[](index);
    }
    bool operator==(const Slice& slice)
    {
        return (size_ == slice.size_ && memcmp(data_, slice.data_, size_));
    }

// apis
    // TOLN: 不加const后缀的 const对象无法使用。
    const char* data() const { return data_; }
    size_t size() const { return size_; }
    int compare(const Slice& b) {
        size_t minLen = (b.size_ > size_)?size_:b.size_;
        int result = memcmp(data_, b.data_, minLen);
        if (result == 0) {
            if (b.size_ > size_) {
                result = -1;
            } else if (b.size_ < size_) {
                result = 1;
            }
        }
        return result;
    }

private:
// data members
    const char* data_;
    size_t size_;
};


#endif