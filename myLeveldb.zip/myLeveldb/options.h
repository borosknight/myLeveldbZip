#ifndef LEVELDB_OPTIONS_H
#define LEVELDB_OPTIONS_H
#include "lookupKey.h"
#include <memory>

namespace myLeveldb {
struct Options {
    Options() : comparator(std::make_unique<BytewiseComparator>()) {}
    std::unique_ptr<Comparator> comparator;
    int restartInterval = 12;
};
}

#endif