#include "arena.h" // TOLN: 要使用引号而不是尖括号！因为不是系统库
#include <cstdint> // uintptr_t

char* Arena::AllocateFallback(size_t bytes) {
    if (bytes >= kBlockSize / 4) {
        return AllocateNewBlock(bytes);
    }
    // 先重新分配一个block
    alloc_ptr_ = AllocateNewBlock(kBlockSize);
    alloc_memory_remaining_ = kBlockSize;
    // 然后分配bytes
    // 注意要返回的是分配内存的起始位置！
    // 而不是+=bytes后的位置
    char* result = alloc_ptr_;
    MovePtrWithinBlock(bytes);
    return result;
}

char* Arena::Allocate(size_t bytes) {
    if (bytes > alloc_memory_remaining_) {
        return AllocateFallback(bytes);
    }
    char* result = alloc_ptr_;
    MovePtrWithinBlock(bytes);
    return result;
    // 错误的实现：
    // 关键在于如果bytes >= kBlockSize / 4 而当前block还有余量
    // 那么应当继续分配到当前block 而不是去分配一个大小一样的block
    // // 需求分配的太大了
    // if (bytes >= kBlockSize / 4) {
    //     // 直接分配一个刚刚好的block
    //     // 而alloc_ptr_在原地 继续使用
    //     return AllocateNewBlock(bytes);
    // }
    // if (bytes > alloc_memory_remaining_) {
    //     // 以kBlockSize重新分配一个block
    //     alloc_ptr_ = AllocateNewBlock(kBlockSize);
    //     alloc_memory_remaining_ = kBlockSize;
    // }
    // MovePtrWithinBlock(bytes);
    // return alloc_ptr_;
}

char* Arena::AllocateAligned(size_t bytes) {
    constexpr size_t alignment = (sizeof(void*) > 8)?sizeof(void*):8;
    constexpr size_t alignment_mask = alignment - 1;
    static_assert((alignment & alignment_mask) == 0); // TOLN: 经典的二次幂判断方法
    //if (alloc_ptr_ != nullptr) { // TODO: 必要吗? reinterpret_cast<uintptr_t>(nullptr)似乎是0
    uintptr_t alloc_ptr_addr = reinterpret_cast<uintptr_t>(alloc_ptr_);
    uintptr_t addr_mod = alloc_ptr_addr & alignment_mask;
    uintptr_t jump = (alignment - addr_mod) & alignment_mask;
    uintptr_t needed = jump + bytes; // TOLN: 这里直接size_t和uintptr_t就加上了 没问题吗？
    if (needed <= alloc_memory_remaining_) {
        char* result = alloc_ptr_ + jump;
        MovePtrWithinBlock(needed);
        return result;
    }
    //}
    // new出来的总是aligned的
    return AllocateFallback(bytes);
}

char* Arena::AllocateNewBlock(size_t bytes) {
    char* blockPtr = new char[bytes];
    blocks_.push_back(blockPtr);
    total_memory_ += bytes;
    return blockPtr;
}

size_t Arena::GetMemoryUsed() {
    return total_memory_;
}