#ifndef LOOKUPKEY_H
#define LOOKUPKEY_H

#include <stdint.h>
#include <cassert>
#include "slice.h"

namespace myLeveldb {

enum ValueType {
    TypeDelete = 0x0,
    TypeValue = 0x1
};
static const ValueType kTypeSearch = TypeValue;

uint64_t PackSeqFlag(uint64_t sequenceNumber, ValueType v);

uint64_t GetSeqNum(uint64_t packedSeqFlag);

ValueType GetFlag(uint64_t packedSeqFlag);

using SeqNumType = uint64_t;
class LookupKey {
public:
// ctor && dctor
    LookupKey(const Slice& ukey, SeqNumType sequenceNumber);
    LookupKey(const LookupKey&) = delete;
    LookupKey& operator=(const LookupKey&) = delete;
    ~LookupKey() {
        if (start_ != space_) { // heap allocation is used
            delete[] start_;
        }
    }

// api
    void print();
    Slice MemTableKey() const { return Slice(start_, end_-start_); }
    Slice InternalKey() const { return Slice(kstart_, end_-kstart_); }
    Slice UserKey() const { return Slice(kstart_, (end_-kstart_)-8); };

private:
// data member
    const char* start_;
    const char* kstart_;
    const char* end_;
    char space_[200]; // stack allocation if possible
};

class Comparator {
public:
// ctor & dctor
    virtual ~Comparator() = default;
// apis
    virtual int Compare(const Slice& a, const Slice& b) const = 0;
};

class BytewiseComparator : public Comparator {
public:
    int Compare(const Slice& a, const Slice& b) const override
    {   
        const char* charA = a.data();
        const char* charB = b.data();
        size_t lenA = a.size(); // TOLN: 用strlen(charA)就大错特错啦
        size_t lenB = b.size();
        int result = memcmp(charA, charB, std::min(lenA, lenB));
        if (result == 0) {
            if (lenA > lenB) {
                result = 1;
            } else if (lenA < lenB) {
                result = -1;
            }
        }
        return result;
    }
};

Slice GetUserKey(const Slice& internalKey)
{
    assert(internalKey.size() > 8);
    return Slice(internalKey.data(), internalKey.size()-8);
}

Slice GetSequenceNumber(const Slice& internalKey)
{
    assert(internalKey.size() > 8);
    return Slice(internalKey.data()+internalKey.size()-8, 8);
}

class InternalKeyComparator : public Comparator {
public:
    int Compare(const Slice& a, const Slice& b) const override
    {
        Slice akey = GetUserKey(a);
        Slice bkey = GetUserKey(b);
        int result = userKeyComparator->Compare(akey, bkey);
        if (result == 0) {
            Slice aSeqSlice = GetSequenceNumber(a);
            Slice bSeqSlice = GetSequenceNumber(b);
            uint64_t aSeq = DecodeFixed64(aSeqSlice.data());
            uint64_t bSeq = DecodeFixed64(bSeqSlice.data());
            if (aSeq > bSeq) {
                result = -1;
            } else if (aSeq < bSeq) {
                result = 1;
            }
        }
        return result;
    }
private:
    const Comparator* userKeyComparator;
};

}

#endif