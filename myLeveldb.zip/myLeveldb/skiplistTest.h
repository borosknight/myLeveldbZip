#ifndef SKIPLISTTEST_H
#define SKIPLISTTEST_H
#include "skiplist.h"

struct TestComparator {
int compare(const uint64_t& a, const uint64_t& b) const {
    if (a < b) {
    return -1;
    } else if (a > b) {
    return +1;
    } else {
    return 0;
    }
}
};

#endif