#ifndef MEMTABLE_H
#define MEMTABLE_H
#include "skiplist.h"
#include "lookupKey.h"
#include "status.h"

namespace myLeveldb {
class MemTable {
public:
// ctor & dctor
    MemTable(InternalKeyComparator cmp): comparator_(cmp), table_(&arena_, comparator_) {}
    MemTable(const MemTable&) = delete;
    MemTable& operator=(const MemTable&) = delete;
// apis
    void Add(uint64_t sequenceNumber, ValueType flag,
        const Slice& key, const Slice& value);

    bool Get(const LookupKey& key, std::string* value, Status* status);

private:
// type
    struct KeyComparator {
        const InternalKeyComparator internalKeyComparator_;
        explicit KeyComparator(const InternalKeyComparator& c) : 
            internalKeyComparator_(c) {}
        int operator()(const char* a, const char* b);
    };
    using Table = SkipList<const char*, KeyComparator>;

// data member
    Arena arena_; // TOLN: 默认构造，那么就不需要出现在构造函数中
    KeyComparator comparator_;
    Table table_; 
};
}

#endif