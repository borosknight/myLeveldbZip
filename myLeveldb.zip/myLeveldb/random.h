#ifndef RANDOM_H
#define RANDOM_H
// 线性同余随机数生成器 https://en.wikipedia.org/wiki/Linear_congruential_generator
// 下一个随机数由上一个随机数线性求余得到
// Xn+1 = (aXn+c) mod m
// 关键问题：这么得到的随机数序列 是存在**周期**的。
// 如何证明这一点？
// 假设已经生成了seq = {X1,X2...Xk}, 那么如果Xk+1∈seq, 比如Xk+1 = X10
// 那么Xk+2必然等于X11...于是开始重复。
// 那么...LCG的最长周期只能是m (0到m有m+1个数 然后0和m一样的效果)了。因为要满足这个序列上的数各不相同
// 那么如何抵达这个最长周期？有许多人提出了各种充分条件
// 我们这里用到了两个神奇的数字 能够几乎抵达这个最长周期
// a = 7^5 m = 2^31-1 c = 0
// 但是 千万别让X0 = 0或者2^31-1...否则就陷在2^31-1->0->0->0->...
// 所以 这里的周期长度是2^31-2 基本够用了
// 另外还有一个著名的充分条件是Hull-Dobell定理。
#include <cstdint> // uint32_t

class Random {
private:
// data member
    uint32_t seed_;

public:
// ctor & dctor
    // TOLN: 0x7fffffffu即2^31-1
    explicit Random(uint32_t s): seed_(s & 0x7fffffffu) {
        if (seed_ == 0 || seed_ == 0x7fffffffu) {
            seed_ = 1;
        }
    }

// apis
    uint32_t Next() {
        // a就是一个五位数 乘上一个32位的，64位已经足够
        static constexpr uint64_t a = 16807;
        // TOLN:
        // 1. 1<<31才是2^31 2<<31是2^32
        // 2. 为什么要用1u: 因为int的范围正是-2^31~2^31-1
        //    而c++中字面值整数 默认是int
        //    那么1<<31 已经超出了int的范围 哪怕后续还要-1
        //    非常有意思 这个2^31-1既是mod又是int的最大值
        // 3. 最保险的还是用2147483647L。可能不加L也没问题因为恰好是int的最大值
        //    但是 还是写个L吧。或者u。uint的范围略大一些 0~2^32-1
        static constexpr uint32_t m = (1u<<31)-1;
        // TOLN: 这么取余就触发了64位除法 非常的慢
        // seed_ = (a*seed_)%m;
        uint64_t product = a * seed_;
        // TOLN: 我们要使用更加快速的求余方法：只需要把seed_的高位加上低位就能得到取余的值！
        // 证明: x mod (2^31-1) = (x[32-64位]+x[0-31位]) mod (2^31-1) 即可以高位+低位就是取余的值
        // x = (2^31)*188+123456 x[32-64位]=188 x[0-31位]=123456 则
        // x mod (2^31-1) = 188+123456 = 123644
        // 可用python验证: ((2**31)*188+123456)%(2**31-1)
        // 证: 令H=x[32-64位] L=x[0-31位] x = H*(2^31) + L
        // x mod (2^31-1) = (H*(2^31) + L) mod (2^31-1) = (H*(2^31-1) + H + L) mod (2^31-1)
        // = (H+L) mod (2^31-1) 因为L还是会取到2^31-2的 此时就会超出2^31-1 还得再减去2^31-1
        uint64_t highPlusLow = (product >> 31) + (product & m);
        // 不必担心 只要初值不是0或者2^31-1 生成过程就不会变成0或者2^31-1
        // 硬要扣一下: >会比>=快。
        if (highPlusLow > m) {
            highPlusLow -= m;
        }
        // TOLN: 位数长的转位数低的 还是要显式static_cast
        seed_ = static_cast<uint32_t>(highPlusLow);
        return seed_;
    }

    bool OneIn(uint32_t k) {
        return (Next() % k) == 0;
    }

    uint32_t Uniform(uint32_t k) {
        return Next() % k;
    }
};

#endif