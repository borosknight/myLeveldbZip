#ifndef CODING_H
#define CODING_H
#include <stdint.h>
#include <string>

char* EncodeVarint32(char* buf, uint32_t v);
uint32_t DecodeVarint32(const char* buf);
char* EncodeFixedUint64(char* buf, uint64_t v);
const char* GetVarint32Ptr(const char* p, const char* limit, uint32_t* value);
void PutVarint32(std::string* dst, uint32_t v);
size_t VarintLength(uint32_t v);
void PutFixed64(std::string* dst, uint64_t v);
uint64_t DecodeFixed64(const char* buf);
void PutFixed32(std::string* dst, uint32_t v);
#endif